package com.example.capstoneproject.utils;

public class Utils {

    public static int[] adapterLengths = { 0, 0, 0};

    public static void setAdapterLengths(int index, int value) {
        adapterLengths[index] = value;
    }
}
